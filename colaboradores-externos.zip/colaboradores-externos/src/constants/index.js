export const API_URL = process.env.VUE_APP_API_URL;

/*export const APP_INFO = Object.freeze({
  name: process.env.VUE_APP_TITLE,
  version: process.env.VUE_APP_VERSION,
  owner: {
    fullName: "Superintendência de Tecnologia da Informação e Comunicação",
    shortName: "TIC"
  },
  system: {
    name: process.env.VUE_APP_SYSTEM_TITLE
  }
});*/

export const DEFAULT_COLOR = process.env.VUE_APP_STYLE_DEFAULT_COLOR;
export const DEFAULT_LUMINOSITY = process.env.VUE_APP_STYLE_DEFAULT_LUMINOSITY;

//export const HELP_INFOTIC_URL = process.env.VUE_APP_HELP_INFOTIC_URL;

export const INFO_CARD_BG_COLOR = "grey";
export const INFO_CARD_BG_LUMINOSITY = DEFAULT_LUMINOSITY;
export const INFO_CARD_TEXT_COLOR = "white-text";

export const PROGRESS_BAR_BG_COLOR = DEFAULT_COLOR;
export const PROGRESS_BAR_BG_LUMINOSITY = "lighten-5";
export const PROGRESS_BAR_SLIDER_COLOR = DEFAULT_COLOR;
export const PROGRESS_BAR_SLIDER_LUMINOSITY = "lighten-1";
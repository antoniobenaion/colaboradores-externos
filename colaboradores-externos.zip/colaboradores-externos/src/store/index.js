export default {
    namespaced: true,
    state: {
      breadcrumbs: []
    },
    mutations: {},
    actions: {},
    modules: {}
  };
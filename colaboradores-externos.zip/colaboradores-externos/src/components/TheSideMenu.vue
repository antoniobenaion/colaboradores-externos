<template>
  <ul id="modulo-implanta-side-menu" class="collection with-header" v-bind:class="shadow">
    <li class="collection-header logo center" v-bind:class="[color, luminosity]">
      <router-link to="/modulos/colaboradores-externos">
        <img class="responsive-img" src="../assets/logo3infotic.png" title alt />
      </router-link>
      <p class="white-text">{{ appName }} | V.: {{ appVersion }}</p>
    </li>
    <li class="collection-item">
      <!--BaseRouterLink to="/modulos/colaboradores-externos" icon-name="home" class="sidenav-close">Home</BaseRouterLink-->
    </li>
    <li class="collection-item">
      <!--BaseRouterLink
        to="/modulos/implanta/implanta-servidor"
        icon-name="assignment_ind"
        class="sidenav-close"
      >Implanta servidor</BaseRouterLink-->
    </li>
  </ul>
</template>

<script>
import { APP_INFO, DEFAULT_COLOR, DEFAULT_LUMINOSITY } from "../constants";

export default {
  name: "TheSideMenu",
  data() {
    return {
      color: DEFAULT_COLOR,
      luminosity: DEFAULT_LUMINOSITY,
      shadow: "z-depth-1",
      appName: APP_INFO.name,
      appVersion: APP_INFO.version
    };
  },
  mounted() {
    window.M.Sidenav.init(this.$refs.sidenav);
  }
};
</script>

<style>
#modulo-implanta-side-menu .collection-item {
  padding: 10px 20px;
}

#modulo-implanta-side-menu .collection-item a {
  color: inherit;
}

@media only screen and (max-width: 992px) {
  #modulo-implanta-side-menu {
    display: none;
  }
}
</style>

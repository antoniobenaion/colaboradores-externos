<template>
  <ul id="modulo-colaboradores-externos-sidenav" ref="sidenav" class="sidenav">
    <li class="logo center" v-bind:class="[color, luminosity]">
      <router-link to="/modulos/colaboradores-externos">
        <img src="../assets/logo3infotic.png" title alt />
      </router-link>
      <p class="white-text">{{ appName }} | V.: {{ appVersion }}</p>
    </li>
    <li>
      <!--BaseRouterLink to="/modulos/colaboradores-externos" icon-name="home" class="sidenav-close">Home</BaseRouterLink-->
    </li>
    <li>
      <!--BaseRouterLink
        to="/modulos/colaboradores-externos/implanta-servidor"
        icon-name="assignment_ind"
        class="sidenav-close"
      >Implanta servidor</BaseRouterLink-->
    </li>
  </ul>
</template>

<script>
import { APP_INFO, DEFAULT_COLOR, DEFAULT_LUMINOSITY } from "../constants";

export default {
  name: "TheHeaderSidenav",
  data() {
    return {
      color: DEFAULT_COLOR,
      luminosity: DEFAULT_LUMINOSITY,
      appName: APP_INFO.name,
      appVersion: APP_INFO.version
    };
  },
  mounted() {
    window.M.Sidenav.init(this.$refs.sidenav);
  }
};
</script>

<style>
#modulo-colaboradores-externos-sidenav .logo {
  border-bottom: 1px solid rgba(0, 0, 0, 0.14);
}
#modulo-colaboradores-externos-sidenav .logo a {
  padding: 0px;
  display: inline;
}
#modulo-colaboradores-externos-sidenav .logo a:hover {
  background: none;
}
</style>

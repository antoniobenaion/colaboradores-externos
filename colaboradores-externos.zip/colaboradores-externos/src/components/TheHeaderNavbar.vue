<template>
  <nav class="nav-extended" v-bind:class="[color, luminosity]">
    <div class="nav-wrapper">
      <div class="row">
        <a href="#!" data-target="modulo-colaboradores-externos-sidenav" class="sidenav-trigger">
          <i class="material-icons">menu</i>
        </a>
        <BaseBreadcrumbs v-bind:breadcrumbs="breadcrumbs" class="col" />
      </div>
    </div>
  </nav>
</template>

<script>
import { DEFAULT_COLOR, DEFAULT_LUMINOSITY } from "../constants";

export default {
  name: "TheHeaderNavbar",
  data() {
    return {
      color: DEFAULT_COLOR,
      luminosity: DEFAULT_LUMINOSITY
    };
  },
  computed: {
    breadcrumbs() {
      return this.$store.state.colaboradoresExternos.breadcrumbs;
    }
  }
};
</script>

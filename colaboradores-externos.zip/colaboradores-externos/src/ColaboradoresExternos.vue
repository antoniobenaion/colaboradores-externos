<template>
  <div id="modulo-colaboradores-externos">
    <!--TheHeader /-->
    <main>
      <div class="row">
        <div class="col l4 xl3" id="modulo-colaboradores-externos-side-menu-container">
          <!--TheSideMenu /-->
        </div>
        <div class="col l8 xl9" id="modulo-colaboradores-externos-router-view-container">
          <!--router-view /-->
        </div>
      </div>
      <!--BaseHelpInfotic v-bind="helpInfotic" /-->
    </main>
  </div>
</template>

<script>
//import { APP_INFO, HELP_INFOTIC_URL } from "./constants";
//import TheHeader from "./components/TheHeader.vue";
//import TheSideMenu from "./components/TheSideMenu.vue";

export default {
  name: "ColaboradoresExternos",
  /*components: {
    TheHeader,
    TheSideMenu
  },
  data() {
    return {
      helpInfotic: {
        contactModalId: "help-infotic-implanta-modal-contatos",
        contacts: [{ name: "PR-4", email: "cadastro@pr4.ufrj.br" }],
        helpUrl: `${HELP_INFOTIC_URL}/duvidas-sistema/${APP_INFO.system.name}-${APP_INFO.name}`
      }
    };
  }*/
};
</script>

<style>
#modulo-colaboradores-externos {
  display: flex;
  min-height: 100%;
  flex-direction: column;
  min-width: 100%;
}

#modulo-colaboradores-externos main {
  flex: auto;
}

@media only screen and (max-width: 992px) {
  #modulo-colaboradores-externos-router-view-container {
    width: 100%;
  }
}
</style>
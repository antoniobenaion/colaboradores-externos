//import Vue from 'vue'
//import App from './App.vue'
import ColaboradoresExternos from "./ColaboradoresExternos.vue";
//import routes from "./router";
import state from "./store";

/*Vue.config.productionTip = false

new Vue({
  render: h => h(ColaboradoresExternos),
}).$mount('#app')*/

export default {
  state,
  //routes,
  component: ColaboradoresExternos
};
